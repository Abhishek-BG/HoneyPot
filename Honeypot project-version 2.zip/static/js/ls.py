
firstlog = "Sql Injection Detected"
secondlog="Malicious File Upload Detected"
thirdlog="XSS Detected"
lists =['" or ""="','OR 1=1']
extension_file =['exe','php','bat','py','c','cpp','js','html']