from django.db import models


# Create your models here.
class urls(models.Model):     
    string = models.CharField(max_length=200)
    username = models.CharField(max_length=200)

    def __str__(self):
        return self.string

class logs(models.Model):     
    ip = models.CharField(max_length=200)
    log = models.CharField(max_length=200)
    time = models.CharField(max_length=200)

    def __str__(self):
        return self.ip

class admin(models.Model): 
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=200)

    def __str__(self):
        return self.username

class blocked(models.Model): 
    mip = models.CharField(max_length=200)

    def __str__(self):
        return self.mip