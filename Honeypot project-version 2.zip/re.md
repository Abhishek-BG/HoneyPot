
pip install django-bootstrap-v5
 django-crispy-forms
python manage.py makemigrations
python manage.py migrate
PS E:\anu project- version 1> venv/scripts/activate
py manage.py createsuperuser
Username (leave blank to use 'owner'): admin
Email address: admin@gmail.com
Password: 123456
Password (again): 123456
Superuser created successfully.

syncdb
admin
Admin@123