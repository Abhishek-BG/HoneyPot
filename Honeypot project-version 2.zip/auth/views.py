from distutils import extension
from certifi import where
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from honeypot.models import urls,logs
from django.contrib import messages
from django.shortcuts import render
from django.contrib import auth
from django.contrib.auth import login,logout , authenticate 
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm 
from django.core.files.storage import FileSystemStorage
from django.views.generic import TemplateView
from datetime import datetime
from django.db import models
from honeypot.models import logs
from static.js.ls import firstlog,lists,extension_file,secondlog
now = datetime.now()


#ip 
def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
def home(request):
    #
   """ mip = get_client_ip(request)
    all = logs.objects.all()
    for i in all:
       if mip in i.ip:
            return redirect('redirect')
            #
    else: """      #
   return render(request,"auth/index.html")
def signup(request):
    
    if request.method =='POST':
       username = request.POST['username']
       email = request.POST['email']
       password = request.POST['pass']
       cpass = request.POST['cpass']
       if User.objects.filter(username=username):
            messages.error(request, "Username already exist! Please try some other username.")
            return redirect('home')
        
       if User.objects.filter(email=email).exists():
            messages.error(request, "Email Already Registered!!")
            return redirect('home')
        
       if len(username)>20:
            messages.error(request, "Username must be under 20 charcters!!")
            return redirect('home')

       if password != cpass:
            messages.error(request, "Passwords didn't matched!!")
            return redirect('home')
        
       if not username.isalnum():
            messages.error(request, "Username must be Alpha-Numeric!!")
            return redirect('home')
       user =User.objects.create_user(username,email,cpass)
       user.user_email = email
       user.save()
       login(request, user)
       messages.success(request,"Your Account is Successfully Creatred")
       return redirect('signin')
    return render(request,"auth/signup.html")

def signin(request):
   """ all = logs.objects.all()
    for i in all:
       if i is not None:
            return redirect('redirect')"""
   if request.method == "POST":
        username =  request.POST.get('username')
        password = request.POST.get('pass')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            messages.info(request, "Logged In sucessfully.")
            return redirect('myaccount')
        elif username or password  in lists:
            messages.info(request, "Logged In sucessfully.")
            mip = get_client_ip(request)
            log = logs(ip=mip,log=firstlog,time=now)
            log.save()
            return redirect('myaccount')

        else :
             messages.error(request,"Invalid username or password.")
           
   return render(request,"auth/signin.html")
    
     
def signout(request):
   
    logout(request)
    messages.info(request, "You have successfully logged out.") 
    return redirect("home")

class Dash(TemplateView):
    template_name = 'dash.html'

def myaccount(request):
    """   all = logs.objects.all()
    for i in all:
       if i is not None:
            return redirect('redirect')"""
    mip = get_client_ip(request)
   
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        name =uploaded_file.name
        for ex in extension_file:
           if name.endswith(ex):
              messages.info(request, "File Uploaded.") 
              log = logs(ip=mip,log=secondlog,time=now)
              log.save()
        fs = FileSystemStorage()
        name = fs.save(uploaded_file.name, uploaded_file)
        messages.info(request, "File Uploaded") 
        context['url'] = fs.url(name)
        l =context['url']


        if request.user.is_authenticated:
         user = request.user
         try:
             url = urls(string=l,username=user)
             url.save()
         except:
             url = urls(string=l,username=" ")
             url.save()

    return render(request,'auth/dash.html')


def show(request):
    data = urls.objects.all()
    return render(request, 'auth/dash.html', {'data': data})


def direct( request):
    return render(request, 'auth/redirect.html')
    
def change(request):
    
    mip = get_client_ip(request)
    if request.method == "POST":
        password = request.POST['pass']
        password2 = request.POST.get('cpass')
        if password == password2:
           messages.error(request, password+ " is same has current password")
           return render(request, 'auth/change.html', {'xs': password})
        else:
             if request.user.is_authenticated:
                 user = request.user
                 User = authenticate(username=user,password=password)
                 if User is not None:
                     User.set_password(password2)
                     messages.error(request,"Password is changed")
                 else:
                     messages.error(request," old password is not valid")
    return render(request,'auth/change.html')

